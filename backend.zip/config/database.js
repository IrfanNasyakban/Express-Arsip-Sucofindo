const { Sequelize } = require("sequelize");

const db = new Sequelize('qrefoxku_arsip_sucofindo', 'qrefoxku_admin', 'sucofindo123', {
    host: 'kurumi.kawaiihost.net',
    port: 2083,
    dialect: 'mysql'
})

module.exports = db;